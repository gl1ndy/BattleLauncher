import time
import requests
import tkinter as tk
from tkinter import ttk
from threading import Thread

def main():
	print("start")